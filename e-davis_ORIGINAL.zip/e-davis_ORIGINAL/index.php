<?php require_once 'views/header.php' ?>

<!-- img src="img/grid-blue.jpg" id="bg" style="width:100%;height:100%;position:absolute;top:0;left:0;z-index:-5000;" -->

<div class="row">
    <div class="container col-lg-6">
        <img src="img/logo-500.jpg" alt="Eric Davis logo" class="img img-responsive" id="logo"/>
    </div>
    <div class="container col-lg-6">
        <!-- TODO: Add content for div next to logo?? -->
    </div>
</div>
<br /><br />

<div class="row">
    <div class="container col-lg-4 ">
        <div class="col-lg-12 glowing-border-green trans-bg bio-container">
            <h2 class="bio-heading">Aspiring Developer</h2>
            <p>
		A deeply rooted childhood passion for computers landed me in the Network Administration program at CSCC in 2015. After enrolling in an introduction to programming logic course during my first semester,
            I quickly fell in love with coding. Shortly afterwards, I decided to switch tracks in pursuit of a career in development and will soon receive a B.S. in Web Development from Franklin University!
            </p>
            <a href="https://github.com/edavis25" class="btn bio-link center-block" target="_blank">
                <i class="fa fa-github fa-2x" aria-hidden="true"></i> 
                Github
            </a>
        </div>
    </div>
    <div class="container col-lg-4 ">
        <div class="col-lg-12 glowing-border-cyan trans-bg bio-container">
            <h2 class="bio-heading"><span class="strikeout">Thriving</span> Bitcoin Prospector</h2>
            <p>
                Cryptocurrency enthusiast, amateur trader, &amp; victim of the 2016 Cryptsy collapse. Began mining in 2012 before powering down my rig roughly 2 years later. Most of my humble fortune was lost
                during the collapse of Crypsty in 2016; however, I remain a vigilant supporter of Bitcoin's future!
            </p>
            <a href="" target="_blank" class="btn bio-link center-block">
                <i class="fa fa-btc fa-2x" aria-hidden="true"></i> 
                My Beginners Guide
            </a>
            <a href="#" id="bitcoin-photos" class="btn bio-link center-block" data-toggle="modal" data-target="#btc-modal">
                <i class="fa fa-camera fa-2x" aria-hidden="true"></i> 
                Mining Rig Photos
            </a>
        </div>
    </div>
    <div class="container col-lg-4 ">
        <div class="col-lg-12 glowing-border-yellow trans-bg bio-container">
            <h2 class="bio-heading smaller">Amateur Backend Developer,
                <span class="small1">DBA, </span>
                <span class="small2">Network Admin, </span>
                <span class="small3">Data Scientist...</span>
            </h2>
            <p>
		Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. 
                Cras mattis consectetur purus sit amet fermentum. Fusce dapibus, tellus ac cursus commodo, tortor 
                mauris condimentum nibh.
            </p>
        </div>
    </div>
</div>

<!-- Terminator/skills row -->
<div class="row" id="terminator-row">
    <div class="container glowing-border-red trans-bg">
        <div class="row">
            <br />
            <div id="terminator-wrap" class="container terminator-wrap col-sm-5 col-sm-offset-2 col-sm-offset-0">
                <img src="img/back2skool-notext.jpg" class="img img-responsive" id="terminator-img" />
                <div id="terminator-text1" class="div-absolute"></div>
                <div id="terminator-text2" class="div-absolute"></div>
            </div>
            <div id="skills-wrap" class="container col-sm-7">
                <?php include_once 'views/skills_table.php' ?>
            </div>
        </div>
    </div>
    <div id="terminator-visible-flag">&nbsp;</div><!-- Trigger animation when in viewport -->
</div>

<!-- Philosoper/writings row -->
<div class="row" id="philosopher-row">
    <div class="container glowing-border-pink trans-bg">
        <div class="row">
            <div class="container col-md-7 content-container" id="philosopher-wrap">
                <h2 class="content-heading">Un-insightful Philosopher <br />
                    <span class="text-muted">&amp; Systems Thinker</span>
                </h2>
                <p>
                    Writings, thoughts, &amp; ramblings from a 21st-century online citizen.
                </p>
                <hr class="content-divider-pink"/>
                <a href="docs/e-pluribus-unum.pdf" class="document-link" target="_blank" id="e-pluribus">
                    <i class="fa fa-file-pdf-o" aria-hidden="true"></i>
                    &nbsp;&nbsp;E Pluribus Burning: Social Media Ideological Silos &amp; Echo Chambers
                </a><br />
                <a href="docs/together-strong.pdf" class="document-link" target="_blank">
                    <i class="fa fa-file-pdf-o" aria-hidden="true"></i>
                    &nbsp;&nbsp;Together Strong - A Letter to the Millennial Soldiers of Tolerance
                </a><br />
                <a href="docs/mirco-musolesi-thoughts.pdf" class="document-link" target="_blank">
                    <i class="fa fa-file-pdf-o" aria-hidden="true"></i>
                    &nbsp;&nbsp;Thoughts on Mirco Musolesi's <i>Big Mobile Data Mining: Good or Evil?</i>
                </a><br />
                <a href="docs/human-centered-organizations.pdf" class="white document-link" target="_blank">
                    <i class="fa fa-file-pdf-o" aria-hidden="true"></i>
                    &nbsp;&nbsp;Human Centered Organizations From a Systems Thinking Perspective
                </a>
            </div>
            <div class="container col-md-5">
                <img src="img/bill&ted.png" id="bill-ted" class="img img-responsive center-block" />
            </div>
        </div>
    </div>
</div>

<!-- Projects row -->
<div class="row" id="">
    <div class="container glowing-border-blue trans-bg">
        <div class="row">
            
            <div class="container col-md-7 col-md-push-5 content-container" id="">
                <h2 class="content-heading">Passion Projects <br />
                    <span class="text-muted">&amp; Hobby Code</span>
                </h2>
                <p>
                    Personal hobby projects for education, experience, &amp; the love of code.
                </p>
                <hr class="content-divider-blue" />
		<a href="http://www.jimmyvspub.com" target="_blank" class="document-link" style="font-size: 1.5em">Jimmy V's Grill &amp; Pub</a>
		<br />
		<a href="http://brownsbackerscolumbus.com" target="_blank" class="document-link" style="font-size: 1.5em">Brewery District Browns Backers</a>
		<br />
		<a href="http://cryptx.hopto.org" target="_blank" class="document-link" style="font-size: 1.5em">CryptX (Fictional client branding portfolio)</a>
            </div>
            
            <div class="container col-md-5 col-md-pull-7">
                <img src="img/delorean.png" id="delorean" class="img img-responsive center-block" />
            </div>
            
        </div>
    </div>
</div>


<?php //include_once 'views/bitcoin_overlay.php' ?>
<?php include_once 'views/bitcoin_modal.php' ?>

<?php require_once 'views/footer.php' ?>
