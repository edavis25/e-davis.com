<!-- Use outer div's id in JavaScript/jQuery to show/hide overlay -->
<div id="bitcoin-overlay" class="overlay">
    
    <a href="javascript:void(0)" class="closebtn">&times;</a>
    <div class="overlay-content">
        <!-- Insert Content for Overlay Here -->
        <div class="col-sm-4 col-xs-6">
            <a class="ttip" data-toggle="tooltip" title="Hooray!">
                <img class="img-responsive btc-img" src="img/BTC-miner-1.jpg" />
            </a>
        </div>
        <div class="col-sm-4 col-xs-6">
            <img class="img-responsive btc-img" src="img/BTC-miner-2.jpg" />
        </div>
        <div class="col-sm-4 col-xs-6">
            <img class="img-responsive btc-img" src="img/BTC-miner-3.jpg" />
        </div>
        <div class="col-sm-4 col-xs-6">
            <img class="img-responsive btc-img" src="img/BTC-miner-4.jpg" />
        </div>
        <div class="col-sm-4 col-xs-6">
            <img class="img-responsive btc-img" src="img/BTC-miner-5.jpg" />
        </div>
        <div class="col-sm-4 col-xs-6">
            <img class="img-responsive btc-img" src="img/BTC-miner-7.jpg" />
        </div>
        <div class="col-sm-4 col-xs-6">
            <img class="img-responsive btc-img-horiz" src="img/BTC-miner-6.jpg" />
        </div>
        <div class="col-sm-4 col-xs-6">
            <img class="img-responsive btc-img-horiz" src="img/BTC-miner-9.jpg" />
        </div>
        <div class="col-sm-4 col-xs-6">
            <img class="img-responsive btc-img-horiz" src="img/BTC-miner-8.jpg" />
        </div>
    </div>
</div>