        
        </div> <!-- End page wrapper -->

        <!-- jQuery 3.1.1 -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <!-- Bootstrap 3.3.7 -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!-- Local plugins -->
        <script src="js/jquery.typer.js"></script>
        <script src="js/jquery.visible.min.js"></script>
        <!-- Custom JavaScript -->
        <script src="js/util.js"></script>
        <script src="js/e-davis.js"></script>
        <script>
            $(document).ready(function () {
                var terminatorAnimationFlag = false;
                setBackgroundImage();
                
                // Initialize tooltips
                $('.ttip').tooltip()
                
                // Click Events
                $('#bitcoin-photos').on('click', function() {
                    // $('#bitcoin-overlay').css('height', '100%');
                });
                
                // Overlay close button.
                $(".closebtn").on('click', function() {
                    // $(".overlay").css('height', '0%');
                });
                
                // Scroll Events
                $(document).on('scroll', function() {
                    if ($('#terminator-visible-flag:visible').visible( true, true ) && !terminatorAnimationFlag) {
                        terminatorAnimationFlag = true; // Stop repeat animations
                        animateTerminatorImage();
                        animateSkillBars();
                    }
                });
                
               // Window Resize Events
               $(window).resize(function() {
                  setBackgroundImage(); 
               });
            });
        </script>
    </body>
</html>