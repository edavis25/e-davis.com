<!-- Modal -->
<div class="modal fade" id="btc-modal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content trans-bg">
            <div class="modal-header">
                <div class="container">
                    <a href="#" class="closebtn" data-dismiss="modal">&times;</a>
                    <br /><br />
                    My modest rig went through several changes throughout its lifetime as I added and removed 
                    a several GPUs; however, the main build consisted of:
                    <ul>
                        <li>2x XFX AMD 7950s</li>
                        <li>1x XFX AMD 6950</li>
                        <li>AMD Phenom II x2</li>
                        <li>2x 600w PSUs</li>
                        <li>16GB USB Drive w/ Ubuntu</li>
                        <li>2x Milk Crates</li>
                    </ul>
                </div>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-4">
                        <a class="ttip" data-toggle="tooltip" title="Running 1x 7950 & 1x 6950">
                            <img class="img img-responsive btc-img" src="img/BTC-miner-1.jpg" />
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a class="ttip" data-toggle="tooltip" title="Earliest version running 1x 5770">
                            <img class="img-responsive btc-img" src="img/BTC-miner-2.jpg" />
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a class="ttip" data-toggle="tooltip" title="Full build with 2x 7950s & 6950">
                            <img class="img-responsive btc-img" src="img/BTC-miner-3.jpg" />
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a class="ttip" data-toggle="tooltip" title="2x 600w PSUs daisy-chained together">
                            <img class="img-responsive btc-img" src="img/BTC-miner-4.jpg" />
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a class="ttip" data-toggle="tooltip" title="Add2PSU component used to daisy-chain the 2 PSUs. WIth each card pulling 200 watts, I decided to put an old PSU I had sitting around to work">
                            <img class="img-responsive btc-img" src="img/BTC-miner-5.jpg" />
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a class="ttip" data-toggle="tooltip" title="Top-down view of full build">
                            <img class="img-responsive btc-img" src="img/BTC-miner-7.jpg" />
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a class="ttip" data-toggle="tooltip" title="Top-down view of full build">
                            <img class="img-responsive btc-img-horiz" src="img/BTC-miner-6.jpg" />
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a class="ttip" data-toggle="tooltip" title="PCIe 1x-to-16x risers for the GPUs">
                            <img class="img-responsive btc-img-horiz" src="img/BTC-miner-9.jpg" />
                        </a>
                    </div>
                    <div class="col-sm-4">
                        <a class="ttip" data-toggle="tooltip" title="Profile shot of the full milk-crate build">
                            <img class="img-responsive btc-img-horiz" src="img/BTC-miner-8.jpg" />
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>