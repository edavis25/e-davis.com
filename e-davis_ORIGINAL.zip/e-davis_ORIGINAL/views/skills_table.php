<table id="skills-table">
    <tr>
        <td><h4 class="skill-label" id="bootstrap-label"></h4></td>
        <td class="full-width"><div id="bootstrap-bar"></div></td>
    </tr>
    <tr>
        <td><h4 class="skill-label" id="css-label"></h4></td>
        <td class="full-width"><div id="css-bar"></div></td>
    </tr>
    <tr>
        <td><h4 class="skill-label" id="html-label"></h4></td>
        <td class="full-width"><div id="html-bar"></div></td>
    </tr>
    <tr>
        <td><h4 class="skill-label" id="javascript-label"></h4></td>
        <td class="full-width"><div id="javascript-bar"></div></td>
    </tr>
    <tr>
        <td><h4 class="skill-label" id="java-label"></h4></td>
        <td class="full-width"><div id="java-bar"></div></td>
    </tr>
    <tr>
        <td><h4 class="skill-label" id="php-label"></h4></td>
        <td class="full-width"><div id="php-bar"></div></td>
    </tr>
    <tr>
        <td><h4 class="skill-label" id="sql-label"></h4></td>
        <td class="full-width"><div id="sql-bar"></div></td>
    </tr>
    <tr>
        <!-- td><h4 class="skill-label"><b>Word<br />Press</b></h4></td>
        <td class="full-width"><div id="wordpress-bar"></div></td -->
    </tr>
</table>
