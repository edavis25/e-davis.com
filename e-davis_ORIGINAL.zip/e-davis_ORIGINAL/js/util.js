"use strict";

/**
 * @author Hei Wah Chan
 *
 *
 * Gist Uploader's Note: This file was created and provided by one of my professors at Franklin University. 
 * These functions provide simple ways to interact with HTML elements (mainly forms) via plain JavaScript.
 */

/**
 * Find Element: Find and return an element using its ID
 * Throw an exception if the element is not found
 * @param {string} elt - HTML element's ID
 * @return {element} - Return a reference to the element
 */
function findElement(elt) {
    var element = elt;
    if (typeof elt === "string") {
        element = document.getElementById(elt);
    }
    if (typeof element === 'undefined' || element === null) {
        throw "Could not find element with ID ''" + elt + "'";
    }
    return element;
}

/**
 * Get Value: Uses findElement to retrieve the value from a form input
 * @param {string} field - HTML element's ID
 * @param {Object} converter - (Optional) Function to parse/convert the input to desired type (ex: parseInt)
 */
function getValue(field, converter) {
    var element = findElement(field);
    var result = element.value;
    if (typeof converter === "function") {
        result = converter(result);
    }
    return result;
}

function isNotEmpty(field) {
    var value = getValue(field);
    if (value === "" || value === null) {
        alert(field + " may not be empty.");
        return false;
    }
    return true;
}

function isBetween(field, low, high) {
    var value = getValue(field, parseFloat);
    if (value < low || value > high) {
        alert(field + " must be in the range ["
                + low + ", " + high + "].");
        return false;
    }
    return true;
}

function isZipcode(field) {
    var value = getValue(field);
    var pattern = /^\d{5}([\-]\d{4})?$/;
    if (!pattern.test(value)) {
        alert(field + " is not a valid zipcode.");
        return false;
    }
    return true;
}

function isTelephone(field) {
    var value = getValue(field);
    var pattern = /^\d{3}[\-]\d{3}[\-]\d{4}$/;
    if (!pattern.test(value)) {
        alert(field + " is not a valid telephone number.");
        return false;
    }
    return true;
}

function setValue(field, value) {
    var element = findElement(field);
    var oldValue = element.value;
    element.value = value;
    return oldValue;
}

/**
 * Get Checked Values - Return array containing checked values from a group
 * @param {String} name - HTML form group's name
 */
function getCheckedValues(name) {
    var result = [];
    var elements = document.getElementsByName(name);
    for (var i = 0; i < elements.length; ++i) {
        if (elements[i].checked) {
            result.push(elements[i].value);
        }
    }
    return result;
}

/**
 * Get Options - Return array containing selected options
 * @param {String} field - HTML element's ID
 */
function getOptions(field) {
    var result = [];
    var options = findElement(field).options;
    for (var i = 0; i < options.length; ++i) {
        if (options[i].selected) {
            result.push(options[i].value);
        }
    }
    return result;
}

/**
 * Set Div - Creates inner html content inside a div
 * @param {String} div - HTML ID for the div
 * @param {String} html - HTML string containing the content for the div
 */
function setDiv(div, html) {
    findElement(div).innerHTML = html;
}

/**
 * Get Div - Return the inner html content from a div
 * @param {Object} div - HTML ID for the div
 */
function getDiv(div) {
    return findElement(div).innerHTML;
}

/**
 * Append Div - Appends additional content to a div without overwriting existing content
 * @param {String} div - HTML ID for the div
 * @param {String} html - HTML string containing content to add to the div
 */
function appendDiv(div, html) {
    setDiv(div, getDiv(div) + html);
}